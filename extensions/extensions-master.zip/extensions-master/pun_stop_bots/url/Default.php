<?php
/**
 * Default SEF URL scheme.
 *
 * @copyright (C) 2008-2009 PunBB
 * @license http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 * @package pun_stop_bots
 */
 
$forum_url['pun_stop_bots_section'] = 'admin/settings.php?section=pun_stop_bots_questions';

?>